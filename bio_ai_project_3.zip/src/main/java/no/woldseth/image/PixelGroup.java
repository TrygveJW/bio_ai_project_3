package no.woldseth.image;

import java.util.ArrayList;
import java.util.HashSet;

public class PixelGroup {
    public ArrayList<Pixel> groupMembers;

    public PixelGroup() {
        groupMembers = new ArrayList<>();
    }
}
