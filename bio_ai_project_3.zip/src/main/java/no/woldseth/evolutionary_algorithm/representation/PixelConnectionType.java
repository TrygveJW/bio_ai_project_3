package no.woldseth.evolutionary_algorithm.representation;

public enum PixelConnectionType {
    UP,
    LEFT,
    DOWN,
    RIGHT,
    SELF,
}
