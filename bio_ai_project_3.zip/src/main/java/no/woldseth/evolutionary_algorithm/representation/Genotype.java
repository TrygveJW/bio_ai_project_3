package no.woldseth.evolutionary_algorithm.representation;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Genotype {
    public PixelConnectionType[] genome;


}
